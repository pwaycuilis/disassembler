Team 23 members

Name:	Paul Waycuilis
netID:	pkw20
e-mail:	pkw20@txstate.edu

Name:	Victor Hernandez
netID:	v_h74
email:	vichdz97@txstate.edu







